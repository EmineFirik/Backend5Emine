package com.neotech.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.neotech.utils.CommonMethods;

public class QualificationsPageElements  extends CommonMethods{
    //###############	
    //workexperience 1
	
	@FindBy(xpath="//a[@id='top-menu-trigger']")
	public WebElement More;
	
	
	@FindBy(xpath="//*[@id='top-menu-overflow']/li[8]/a/span[2]")
	public WebElement qualification;
	
	
	@FindBy(xpath="//a[@id='top-menu-trigger']")
	public WebElement PlusButton;
	
	
	@FindBy(xpath="//a[text()='Work Experience']")
	public WebElement workexperince;
	
	
	@FindBy(id="employer")
	public WebElement companyName;
	
	
	
	@FindBy(id="jobtitle")
	public WebElement jobTitle;
	
	
	@FindBy(xpath="//label[@for='creditable']")
	public WebElement Creditable;
	
	
	@FindBy(id="comments")
	public WebElement commentBar;
	
	
	@FindBy(id="modal-save-button")
	public WebElement saveButton;
	
	
	@FindBy(xpath="//input[@id='from_date']")//yeni
	public WebElement fromDate;
	
	
	@FindBy(xpath="//input[@id='to_date']")//yeni
	public WebElement toDate;
	
	//###################
	//Education 2########
	
	@FindBy(xpath="//a[text()='Education']")
	public WebElement education;
	
	@FindBy ( id="educationId")
	public WebElement selectLevel;
	
	@FindBy(id="institute")
	public WebElement institute;
	
	@FindBy(id="major")
	public WebElement major;
	
	@FindBy (id ="year")
	public WebElement year;
	
	@FindBy(id="score")
	public WebElement GPAScore;
	
	@FindBy(xpath = "//input[@id='startDate']")
	public WebElement educationStartDate;
	
	@FindBy(xpath ="//input[@id='endDate']")
	public WebElement educationEndDate;
		
	//#######################
	//Skill 3
	@FindBy(xpath="//a[text()='Skill']")
	public WebElement skill;
	
	@FindBy(xpath = "//div[@class='dropdown bootstrap-select select-dropdown']/button")
	public WebElement skillSelectButton;
	
	@FindBy(xpath="//div[@class='dropdown-menu show']/div[@class='inner show']//ul/li")
	public List<WebElement> Skillselect;
	
	@FindBy(id="years_of_exp")
	public WebElement yearsOfexperience;
	
	@FindBy(id="comments")
	public WebElement skillComment;
		
	@FindBy(xpath = "//div[@class='toast-message']")
	public WebElement toastMessage;
	
	//##########################
	//Language 4
	@FindBy(xpath="//a[text()='Language']")
	public WebElement language;
	
	@FindBy(xpath="//div[@class='dropdown bootstrap-select select-dropdown']/button")
	public WebElement clickLanguage;
	
	@FindBy(xpath="//div[@class='dropdown-menu show']/div[@class='inner show']//ul/li")
	public List<WebElement> languageSelectbutton;
	
	
	@FindBy(xpath="//select[@id='fluency']/parent::div/button[1]")
	public WebElement clickSkill;
	
	@FindBy(xpath="//div[@class='dropdown-menu show']/div[@class='inner show']//ul/li")
	public List<WebElement> selectSkill;
	
	@FindBy(xpath="//*[@id='modal-holder']/div/div/div/div[2]/form/oxd-decorator[2]/div/div/div/div[1]/button")
	public WebElement Clickfluency;
	
	
	@FindBy(xpath="//div[@class='dropdown-menu show']/div[@class='inner show']//ul/li")
	public List<WebElement> selectFluency;
	
	@FindBy(id="comments")
	public WebElement languageComment;
	
	//##############################
	//Licence 5
	
	@FindBy(xpath="//a[text()='License']")
	public WebElement license;
	
	
	@FindBy(xpath="//select[@id='licenseId']/parent::div/button[1]") 
	public WebElement clickLicense;
	
	
	@FindBy(xpath="//div[@class='dropdown-menu show']/div[@class='inner show']//ul/li")
	public List<WebElement> selectLicense;
	
	@FindBy(xpath="//input[@id='licenseNo']")
	public WebElement licenceNumber;
	
	@FindBy (id="licenseIssuedDate")
	public WebElement issuedDate;
	
	@FindBy(id="licenseExpiryDate")
	public WebElement Expirydate;

	
	public QualificationsPageElements() {
		PageFactory.initElements(driver, this);
	}
	
}
