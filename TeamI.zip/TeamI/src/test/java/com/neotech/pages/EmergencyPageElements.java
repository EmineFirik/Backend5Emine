package com.neotech.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.neotech.utils.CommonMethods;

public class EmergencyPageElements extends CommonMethods{
	
	@FindBy(xpath="//a[@id='top-menu-trigger']")
	public WebElement More;
	
	@FindBy(xpath="//span[text()='Emergency Contacts']")
	public WebElement emergencyContact;
	
	@FindBy(xpath="//*[@id=\"socialMediaDiv\"]/div/a/i")
	public WebElement emergencyPlussButtonn;
	
	@FindBy(id="name")
	public WebElement emergencyName;
	
	
	@FindBy(id="relationship")
	public WebElement relationship;
	
	@FindBy(id="home_phone")
	public WebElement homePhone;
	
	@FindBy(id="mobile_phone")
	public WebElement mobilePhone;
	
	@FindBy(id="office_phone")
	public WebElement workPhone;
	
	@FindBy( id ="modal-save-button")
	public WebElement EmergencySavebutton;
	
	
	@FindBy(xpath = "//div[@class='toast-message']")
	public WebElement toastMessage;
	
	public EmergencyPageElements() {
		PageFactory.initElements(driver, this);
	}
	
	

}
