package com.neotech.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.neotech.utils.CommonMethods;

public class DashboardPageElements extends CommonMethods {

	@FindBy(id = "menu-content")
	public WebElement dashboard;

	@FindBy(id = "ohrm-small-logo")
	public WebElement logo;

	@FindBy(xpath = "//span[text()='PIM']")
	public WebElement Pim;

	@FindBy(xpath = "//span[text()='Add Employee']")
	public WebElement Addemployee;

	public DashboardPageElements() {
		PageFactory.initElements(driver, this);
	}
}
