package com.neotech.steps;

import org.junit.Assert;

import com.neotech.utils.CommonMethods;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddEmergencyContactsteps extends CommonMethods {

	
	@When("I enter a valid username {string} and password {string}")
	public void i_enter_a_valid_username_and_password(String username, String password) {
		
		sendText(login.username, username);
		sendText(login.password,password);
		
	   
	}
	@When("I click login button")
	public void i_click_login_button() {
		click(login.loginButton);
	   
	}
	@When("click PIM button and AddEmployee")
	public void click_pim_button_and_add_employee() {
		click(dahsboard.Pim);
		click(dahsboard.Addemployee);
		
	    
	}
	@When("enter employe name {string}  and lastname {string}")
	public void enter_employe_name_and_lastname(String firstName, String lastName) {
		sendText(addEmployee.firstName, firstName);
		sendText(addEmployee.lastName, lastName);
		
	   
	}
	@When("click location")
	public void click_location() {
		
		selectDropdown(addEmployee.Location, "Canadian Development Center");
	   
	}
	@When("click save")
	public void click_save() {
		waitForClickability(addEmployee.clickSave).click();
	    
	}
	@When("user Click More button")
	public void user_click_more_button() {
		waitForClickability(emergencyList.More).click();
		
		
	   
	}
	@When("click Emergency Contacts from the list")
	public void click_emergency_contacts_from_the_list() {
		
		waitForClickability(emergencyList.emergencyContact).click();
		
	    
	}
	@When("click pluss button")
	public void click_pluss_button() {
		click(emergencyList.emergencyPlussButtonn);
		
	    
	}
	@When("add emergency  {string} and {string} and {string} and {string} and {string}  acontact details")
	public void add_emergency_and_and_and_and_acontact_details(String name, String relationship, String homePhone, String mobilPhone, String workPhone) {
	    
		sendText(emergencyList.emergencyName, name);
		sendText(emergencyList.relationship, relationship);
		sendText(emergencyList.homePhone,homePhone);
		sendText(emergencyList.mobilePhone,mobilPhone);
		sendText(emergencyList.workPhone, workPhone);
		
	}
	@Then("click  emergency save button")
	public void click_emergency_save_button() {
		waitForClickability(emergencyList.EmergencySavebutton).click();
		
	

		String expected = "Successfully Saved";
		if(emergencyList.toastMessage.getText().equals(expected)) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}
		
		
		wait(1);
		
	    
	}


	
}
