package com.neotech.steps;

import org.junit.Assert;
import org.openqa.selenium.By;

import com.neotech.utils.CommonMethods;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddQualificationsSteps extends CommonMethods {

	// WorkExperience********
	// **********************

	@When("I click More button")
	public void i_click_more_button() {
		waitForClickability(Qualifications.More).click();
	}

	@When("I click qualification  pluss button  and work experience")
	public void i_click_qualification_pluss_button_and_work_experience() {

		waitForClickability(Qualifications.qualification).click();

		plusButtonAndOtherClick(Qualifications.workexperince);
	}

	@When("I write to  company name and job title {string} and {string}")
	public void i_write_to_company_name_and_job_title_and(String companyName, String jobTitle) {
		sendText(Qualifications.companyName, companyName);
		sendText(Qualifications.jobTitle, jobTitle);

	}

	@When("I enter Work Experience date from to From {string}")
	public void i_enter_work_experience_date_from_to_from(String startDate) {
		selectDateFromCalendar2(Qualifications.fromDate, 1, startDate);

	}

	@When("I enter   WorkExperience date from to  {string}")
	public void i_enter_work_experience_date_from_to(String endDate) {
		selectDateFromCalendar2(Qualifications.toDate, 2, endDate);

	}

	@When("I click Credential click button and I add comment")
	public void i_click_credential_click_button_and_i_add_comment() {

		click(Qualifications.Creditable);
		sendText(Qualifications.commentBar, "Successfull");

	}

//Education*******
//****************	

	@When("I click qualification  pluss button  and  Education")
	public void i_click_qualification_pluss_button_and_education() {

		waitForClickability(Qualifications.qualification).click();

		plusButtonAndOtherClick(Qualifications.education);

	}

	@When("I select Level {string}  I write Institute {string} Major {string} Year {string} GPAScore {string}")
	public void i_select_level_i_write_institute_major_year_gpa_score(String Level, String Institute, String Major,
			String Year, String GPAScore) {

		selectDropdown(Qualifications.selectLevel, Level);
		wait(1);
		sendText(Qualifications.institute, Institute);
		wait(1);
		sendText(Qualifications.major, Major);
		sendText(Qualifications.year, Year);
		wait(1);
		sendText(Qualifications.GPAScore, GPAScore);
		wait(1);

	}

	@When("Sellect start Date {string} and end date {string}")
	public void sellect_start_date_and_end_date(String startDate, String enddate) {

		selectDateFromCalendar2(Qualifications.educationStartDate, 1, startDate);
		wait(1);
		selectDateFromCalendar2(Qualifications.educationEndDate, 2, enddate);
		wait(1);
	}

	// Skill***************
	// ********************

	@When("I click qualification  pluss button  and  Skill")
	public void i_click_qualification_pluss_button_and_skill() {

		waitForClickability(Qualifications.qualification).click();
		
		plusButtonAndOtherClick(Qualifications.skill);

	}

	@When("Select skill {string} yearsbof experience {string} and add commet {string}")
	public void select_skill_yearsbof_experience_and_add_commet(String Skill, String yearsOfExperience,
			String comment) {

		click(Qualifications.skillSelectButton);//burada select liste click yapildi
		selectDropDownList(Qualifications.Skillselect, Skill);//burada coklu elaman secildi

		sendText(Qualifications.yearsOfexperience, yearsOfExperience);
		sendText(Qualifications.skillComment, comment);

	}

	@Then("Click the Save button and it is seen in screen {string}")
	public void click_the_save_button_and_it_is_seen_in_screen(String message) {
		waitForClickability(Qualifications.saveButton).click();
		wait(3);
		
		
			Assert.assertTrue(true);
	}

	// Language**********
	// ******************

	@When("I click qualification  pluss button  and  Language")
	public void i_click_qualification_pluss_button_and_language() {

		waitForClickability(Qualifications.qualification).click();
		plusButtonAndOtherClick(Qualifications.language);
	}

	
	@When("Select language {string} select  skill {string} select fluency {string}")
	public void select_language_select_skill_select_fluency(String language, String Skill, String fluency) {
	    
		
		click(Qualifications.clickLanguage);//burada select liste click yapildi
		selectDropDownList(Qualifications.languageSelectbutton, language);//burada coklu elaman secildi
		
		click(Qualifications.clickSkill);
		selectDropDownList(Qualifications.Skillselect, Skill);
		
		click(Qualifications.Clickfluency);
		selectDropDownList(Qualifications.selectFluency, fluency);
		
	}
	
	@Then("Add comment {string}")
	public void add_comment(String string) {
	   sendText(Qualifications.languageComment, string);
	}

	

	// License*********
	// ***************

	@When("I click qualification  pluss button  and  License")
	public void i_click_qualification_pluss_button_and_license() {

		waitForClickability(Qualifications.qualification).click();
		plusButtonAndOtherClick(Qualifications.license);

	}
	@When("Select license type {string} add license number {string}")
	public void select_license_type_add_license_number(String LicenseType, String LicenseNumber) {
		
		click(Qualifications.clickLicense);
		wait(1);
		selectDropDownList(Qualifications.selectLicense, LicenseType);
		sendText(Qualifications.licenceNumber, LicenseNumber);

	}
	@When("Select Issued date {string} and Expiry date {string}")
	public void select_issued_date_and_expiry_date(String issuedDate, String expdate) {

		selectDateFromCalendar2(Qualifications.issuedDate, 1, issuedDate);

		selectDateFromCalendar2(Qualifications.Expirydate, 2, expdate);

	}

}
