package com.neotech.testbase;

import com.neotech.pages.AddEmployee;
import com.neotech.pages.DashboardPageElements;
import com.neotech.pages.EmergencyPageElements;
import com.neotech.pages.EmployeListPage;
import com.neotech.pages.LoginPageElements;
import com.neotech.pages.PersonelDetailsElements;
import com.neotech.pages.QualificationsPageElements;

public class PageInitializer extends BaseClass {

	public static LoginPageElements login;
	public static DashboardPageElements dahsboard;
	public static AddEmployee addEmployee;
	public static PersonelDetailsElements personelDetails;
	public static EmployeListPage employeList;
	public static EmergencyPageElements emergencyList;
	public static QualificationsPageElements Qualifications;

	public static void initialize() {
		login = new LoginPageElements();
		dahsboard = new DashboardPageElements();
		addEmployee = new AddEmployee();
		personelDetails = new PersonelDetailsElements();
		employeList = new EmployeListPage();
		emergencyList = new EmergencyPageElements();
		Qualifications = new QualificationsPageElements();

	}

}
